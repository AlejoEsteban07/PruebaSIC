package com.tramites.tramites;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TramitesApplicationTests {

	@Test
	void contextLoads() {
	}

}
